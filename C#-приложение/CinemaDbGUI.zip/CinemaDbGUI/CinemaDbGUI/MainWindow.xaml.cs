﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CinemaDbGUI
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        CinemaEntities _db = new CinemaEntities();
        public MainWindow()
        {
            InitializeComponent();
            UpdateOrders();
            UpdateSpectators();
            UpdateSessions();
            UpdateMovies();
        }
        public void UpdateOrders()
        {
            var query = from Order in _db.Order
                        select new
                        {
                            IDOrder = Order.IDOrder,
                            OrderTime = Order.OrderTime,
                            PaymentMethod = Order.PaymentMethod,
                            IDSpectator = Order.IDSpectator,
                            IDCashier = Order.IDCashier,
                            IDSeat = Order.IDSeat,
                            IDRow = Order.IDRow,
                            IDCinemaHall = Order.IDCinemaHall,
                            IDSession = Order.IDSession,
                        };
            OrdersDataGrid.ItemsSource = query.ToList();
        }
        public void UpdateSpectators()
        {
            SpectatorsDataGrid.ItemsSource = _db.Spectator.ToList();
        }
        public void UpdateMovies()
        {
            var query4 = from Movie in _db.Movie
                         select new
                         {
                             IDMovie = Movie.IDMovie,
                             Name = Movie.Name,
                             Duration = Movie.Duration,
                             Rating = Movie.Rating,
                             AgeRestriction = Movie.AgeRestriction,
                             IDCompany = Movie.IDCompany,
                             IDGenre = Movie.IDGenre,
                             IDDirector = Movie.IDDirector
                         };
            MoviesDataGrid.ItemsSource = query4.ToList();
        }
        public void UpdateSessions()
        {
            var query5 = from Session in _db.Session
                         select new
                         {
                             IDSession = Session.IDSession,
                             Time = Session.Time,
                             Revenue = Session.Revenue,
                             IDCinemaHall = Session.IDCinemaHall,
                             IDMovie = Session.IDMovie
                         };
            SessionsDataGrid.ItemsSource = query5.ToList();
        }
        private void FindOrderButton_Click(object sender, RoutedEventArgs e)
        {
            var query2 = from Order in _db.Order
                         where
                         Order.Spectator.Name == NameTextBox.Text
                         select new
                        {
                            IDOrder = Order.IDOrder,
                            OrderTime = Order.OrderTime,
                            PaymentMethod = Order.PaymentMethod,
                            IDSpectator = Order.IDSpectator,
                            IDCashier = Order.IDCashier,
                            IDSeat = Order.IDSeat,
                            IDRow = Order.IDRow,
                            IDCinemaHall = Order.IDCinemaHall,
                            IDSession = Order.IDSession,
                        };
            OrdersDataGrid.ItemsSource = query2.ToList();
        }
        private void AddOrderButton_Click(object sender, RoutedEventArgs e)
        {
            var addOrderWindow = new AddOrderWindow();
            addOrderWindow.ShowDialog();
        }
        private void showAllOrdersButton_Click(object sender, RoutedEventArgs e)
        {
            UpdateOrders();
        }
        private void addSpectatorButton_Click(object sender, RoutedEventArgs e)
        {
            var addSpectatorWindow = new AddSpectatorWindow();
            addSpectatorWindow.ShowDialog();
        }
        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            var query3 = from LoyaltyCard in _db.LoyaltyCard
                         select new
                         {
                             IDSpectator = LoyaltyCard.IDSpectator,
                             IDLoyaltyCard = LoyaltyCard.IDLoyaltyCard,
                             IsActivated = LoyaltyCard.IsActivated,
                             Discount = LoyaltyCard.Discount,
                             Name = LoyaltyCard.Spectator.Name,
                             Age = LoyaltyCard.Spectator.Age,
                             Email = LoyaltyCard.Spectator.Email,
                             Gender = LoyaltyCard.Spectator.Gender
                         };
            SpectatorsDataGrid.ItemsSource = query3.ToList();
        }
        private void CheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            UpdateSpectators();
        }
        private void refreshSpectatorsButton_Click(object sender, RoutedEventArgs e)
        {
            UpdateSpectators();
        }

        private void revenueButton_Click(object sender, RoutedEventArgs e)
        {
            if (startDateTextBox.Text == "" || endDateTextBox.Text == "")
            {
                MessageBox.Show("Не все данные введены! Повторите еще");
            }
            else
            {
                DateTime startDate = Convert.ToDateTime(startDateTextBox.Text);
                DateTime endDate = Convert.ToDateTime(endDateTextBox.Text);
                var revenueWindow = new RevenueWindow(startDate, endDate);
                revenueWindow.ShowDialog();
            }
        }

        private void addSessionButton_Click(object sender, RoutedEventArgs e)
        {
            var addSessionWindow = new AddSessionWindow();
            addSessionWindow.ShowDialog();
        }

        private void sessionRevenueButton_Click(object sender, RoutedEventArgs e)
        {
            _db.SessionRevenue();
            UpdateSessions();
        }

        private void MoviesCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            var query = from Movie in _db.Movie
                        select new
                        {
                            Movie.IDMovie,
                            Movie.Name,
                            Movie.Duration,
                            Movie.Rating,
                            Movie.AgeRestriction,
                            Genre = Movie.Genre.Name,
                            Company = Movie.Company.Name,
                            Director = Movie.Director.Name
                        };
            MoviesDataGrid.ItemsSource = query.ToList();
        }

        private void MoviesCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            UpdateMovies();
        }

        private void editSpectatorButton_Click(object sender, RoutedEventArgs e)
        {
            if (SpectatorsDataGrid.SelectedItem == null)
            {
                MessageBox.Show("Вы не выбрали клиента! Повторите еще");
            }
            else
            {
                int IDSpectator = (SpectatorsDataGrid.SelectedItem as Spectator).IDSpectator;
                EditSpectatorWindow editSpectatorWindow = new EditSpectatorWindow(IDSpectator);
                if (editSpectatorWindow.ShowDialog() == true)
                {
                    SpectatorsDataGrid.ItemsSource = _db.Spectator.ToList();
                }
            }
        }
    }
}
