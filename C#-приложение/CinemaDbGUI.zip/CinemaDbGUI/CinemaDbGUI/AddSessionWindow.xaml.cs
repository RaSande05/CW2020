﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CinemaDbGUI
{
    /// <summary>
    /// Логика взаимодействия для AddSessionWindow.xaml
    /// </summary>
    public partial class AddSessionWindow : Window
    {
        CinemaEntities _db4 = new CinemaEntities();
        public AddSessionWindow()
        {
            InitializeComponent();
        }

        private void addSessionOkButton_Click(object sender, RoutedEventArgs e)
        {
            if (dateSessionTextBox.Text == "" || idCinemaHallTextBox.Text == "" || idMovieTextBox.Text == "")
            {
                DialogResult = false;
                MessageBox.Show("Не все данные введены! Повторите еще");
            }
            else
            {
                Session newsession = new Session()
                {
                    Time = Convert.ToDateTime(dateSessionTextBox.Text),
                    IDCinemaHall = Convert.ToInt32(idCinemaHallTextBox.Text),
                    IDMovie = Convert.ToInt32(idMovieTextBox.Text)
                };
                _db4.Session.Add(newsession);
                _db4.SaveChanges();
                DialogResult = true;
            }
        }
    }
}
