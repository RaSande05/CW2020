﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CinemaDbGUI
{
    /// <summary>
    /// Логика взаимодействия для EditSpectatorWindow.xaml
    /// </summary>
    public partial class EditSpectatorWindow : Window
    {
        CinemaEntities _db = new CinemaEntities();
        int specId;
        public EditSpectatorWindow(int Id)
        {
            InitializeComponent();
            string[] genders = { "M", "F" };
            genderSpectatorComboBox.ItemsSource = genders;
            specId = Id;
        }

        private void editSpectatorOKButton_Click(object sender, RoutedEventArgs e)
        {
            var query = from Spectator in _db.Spectator
                        where
                          Spectator.IDSpectator == specId
                        select Spectator;
            foreach (var Spectator in query)
            {
                Spectator.Name = nameSpectatorTextBox.Text;
                Spectator.Email = emailSpectatorTextBox.Text;
                Spectator.Gender = genderSpectatorComboBox.Text;
                Spectator.Age = Convert.ToInt32(ageSpectatorTextBox.Text);
            }
            _db.SaveChanges();
            DialogResult = true;
        }
    }
}
