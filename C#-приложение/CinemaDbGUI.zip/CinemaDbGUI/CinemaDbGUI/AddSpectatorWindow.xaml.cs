﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CinemaDbGUI
{
    /// <summary>
    /// Логика взаимодействия для AddSpectatorWindow.xaml
    /// </summary>
    public partial class AddSpectatorWindow : Window
    {
        CinemaEntities _db3 = new CinemaEntities();
        public AddSpectatorWindow()
        {
            InitializeComponent();
            string[] genders = { "M", "F" };
            genderSpectatorComboBox.ItemsSource = genders;
        }

        private void addSpectatorOKButton_Click(object sender, RoutedEventArgs e)
        {
            if (nameSpectatorTextBox.Text == "" || ageSpectatorTextBox.Text == "" || emailSpectatorTextBox.Text == "" || genderSpectatorComboBox.Text == "")
            {
                DialogResult = false;
                MessageBox.Show("Не все данные введены! Повторите еще");
            }
            else
            {
                Spectator newspectator = new Spectator()
                {
                    Name = nameSpectatorTextBox.Text,
                    Age = Convert.ToInt32(ageSpectatorTextBox.Text),
                    Email = emailSpectatorTextBox.Text,
                    Gender = genderSpectatorComboBox.Text
                };
                _db3.Spectator.Add(newspectator);
                _db3.SaveChanges();
                DialogResult = true;
            }

        }
    }
}
