﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CinemaDbGUI
{
    /// <summary>
    /// Логика взаимодействия для RevenueWindow.xaml
    /// </summary>
    public partial class RevenueWindow : Window
    {
        CinemaEntities _db3 = new CinemaEntities();
        public RevenueWindow(DateTime startdate, DateTime enddate)
        {
            InitializeComponent();
            CountRevenue(startdate, enddate);
        }
        public void CountRevenue(DateTime start, DateTime end)
        {
            var query = from Session in
            (from Session in _db3.Session
             where
               Session.Time > start &&
               Session.Time < end
             select new
             {
                 Session.Revenue,
                 Dummy = "x"
             })
                        group Session by new { Session.Dummy } into g
                        select new
                        {
                            Revenue = (int?)g.Sum(p => p.Revenue)
                        };
            RevenueDataGrid.ItemsSource = query.ToList();
        }
    }
}
