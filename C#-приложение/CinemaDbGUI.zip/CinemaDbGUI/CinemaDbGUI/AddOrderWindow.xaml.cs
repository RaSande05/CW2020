﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CinemaDbGUI
{
    /// <summary>
    /// Логика взаимодействия для AddOrderWindow.xaml
    /// </summary>
    public partial class AddOrderWindow : Window
    {
        CinemaEntities _db2 = new CinemaEntities();
        public AddOrderWindow()
        {
            InitializeComponent();
            string[] payment_methods = {"Cash", "Credit card"};
            paymentMethodComboBox.ItemsSource = payment_methods;
        }

        private void addOrderOkButton_Click(object sender, RoutedEventArgs e)
        {
            if (paymentMethodComboBox.Text == "" || idSpectatorTextBox.Text == "" || idCashierTextBox.Text == "" || idSeatTextBox.Text == "" || idRowTextBox.Text == "" || idCinemaHallTextBox.Text == "" || idSessionTextBox.Text == "")
            {
                DialogResult = false;
                MessageBox.Show("Не все данные введены! Повторите еще");
            }
            else
            {
                _db2.AddOrder(paymentMethodComboBox.Text, Convert.ToInt32(idSpectatorTextBox.Text),
                Convert.ToInt32(idCashierTextBox.Text), Convert.ToInt32(idSeatTextBox.Text), Convert.ToInt32(idRowTextBox.Text), Convert.ToInt32(idCinemaHallTextBox.Text), Convert.ToInt32(idSessionTextBox.Text));
                DialogResult = true;
            }
        }
    }
}
